import homeBanner from '../assets/images/slide-1.png'
import loginBanner from '../assets/images/slide-3.png'
import signUpBanner from '../assets/images/slide-2.png'
import girlPng from '../assets/images/girl-bg.png'
export {
    homeBanner,
    loginBanner,
    signUpBanner,
    girlPng
}